--
-- PostgreSQL database dump
--

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.6 (Debian 16.6-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: zettl; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA zettl;


ALTER SCHEMA zettl OWNER TO postgres;

--
-- Name: update_modified_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_modified_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.modified_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_modified_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: zettl_auth
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    user_id integer,
    key_hash character varying(255) NOT NULL,
    name character varying(255),
    permissions jsonb DEFAULT '[]'::jsonb,
    last_used timestamp without time zone,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.api_keys OWNER TO zettl_auth;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: zettl_auth
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO zettl_auth;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zettl_auth
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_id character varying(10) NOT NULL,
    target_id character varying(10) NOT NULL,
    context text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.links OWNER TO postgres;

--
-- Name: notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notes (
    id character varying(10) NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    modified_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notes OWNER TO postgres;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: zettl_auth
--

CREATE TABLE public.refresh_tokens (
    id integer NOT NULL,
    user_id integer,
    token character varying(500) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address character varying(45),
    user_agent text
);


ALTER TABLE public.refresh_tokens OWNER TO zettl_auth;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: zettl_auth
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.refresh_tokens_id_seq OWNER TO zettl_auth;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zettl_auth
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    note_id character varying(10) NOT NULL,
    tag character varying(100) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tags OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: zettl_auth
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying,
    api_key character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone,
    is_active boolean DEFAULT true,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.users OWNER TO zettl_auth;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: zettl_auth
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO zettl_auth;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zettl_auth
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: zettl_auth
--

COPY public.api_keys (id, user_id, key_hash, name, permissions, last_used, expires_at, created_at) FROM stdin;
1	2	ddf04ff6e12e231632eb04b4e5b312630cad492f4f60b98f6205b09bf9ef1859	CLI Test Key	{}	2025-09-23 19:23:07.411163	\N	2025-09-23 19:14:25.459499
\.


--
-- Data for Name: links; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.links (id, source_id, target_id, context, created_at) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notes (id, content, created_at, modified_at) FROM stdin;
848v6	test note	2025-09-23 19:43:04.135+00	2025-09-23 19:43:04.135+00
657xn	test stuff	2025-09-23 19:44:25.797+00	2025-09-23 19:44:25.797+00
119sg	test note	2025-09-23 19:51:51.05+00	2025-09-23 19:51:51.05+00
21qkg	test	2025-09-23 19:58:41.634+00	2025-09-23 19:58:41.634+00
62d6m	super duper test note	2025-09-23 20:02:42.481+00	2025-09-23 20:02:42.481+00
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: zettl_auth
--

COPY public.refresh_tokens (id, user_id, token, expires_at, created_at, ip_address, user_agent) FROM stdin;
3	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsInR5cGUiOiJyZWZyZXNoIiwiaWF0IjoxNzU4NjUzMjEwLCJleHAiOjE3NTkyNTgwMTB9.-h1VEsOMoJmfokwGFBHsjbIuI6dVVwFLJL8MLpsobQQ	2025-09-30 18:46:50.738	2025-09-23 18:46:50.739073	172.26.0.7	python-requests/2.31.0
4	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsInR5cGUiOiJyZWZyZXNoIiwiaWF0IjoxNzU4NjUzMjIyLCJleHAiOjE3NTkyNTgwMjJ9.hRIt2VyumhsZ7CZugvOTbk2iyeTqyvC-SGD0LmAy88M	2025-09-30 18:47:02.325	2025-09-23 18:47:02.325504	172.26.0.7	python-requests/2.31.0
6	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsInR5cGUiOiJyZWZyZXNoIiwiaWF0IjoxNzU4NjU0NzYwLCJleHAiOjE3NTkyNTk1NjB9.Vz_lkNDAKuyo8FDknC_NcnZP5sIQb8WSg2gw6c7JFik	2025-09-30 19:12:40.368	2025-09-23 19:12:40.368948	172.26.0.7	python-requests/2.31.0
7	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsInR5cGUiOiJyZWZyZXNoIiwiaWF0IjoxNzU4NjU0ODQ0LCJleHAiOjE3NTkyNTk2NDR9.3W0OgwZlvpc2Z13QhtwaL53K1Es0o8wFP9kQBdBlbNw	2025-09-30 19:14:04.116	2025-09-23 19:14:04.116876	172.26.0.8	curl/8.16.0
9	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsInR5cGUiOiJyZWZyZXNoIiwiaWF0IjoxNzU4NjU2MDE5LCJleHAiOjE3NTkyNjA4MTl9.KKHouSiI7VNlXhEMA2_EF-lFv5t9zzR-dgSVJZ5sRd0	2025-09-30 19:33:39.823	2025-09-23 19:33:39.823412	172.26.0.8	python-requests/2.32.5
10	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsInR5cGUiOiJyZWZyZXNoIiwiaWF0IjoxNzU4NjU2MDI4LCJleHAiOjE3NTkyNjA4Mjh9.-G8Mzzx6yj8A9SFSna56rB9uTemPN7lAq-m9EfGjwp0	2025-09-30 19:33:48.078	2025-09-23 19:33:48.078269	172.26.0.8	python-requests/2.32.5
13	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsInR5cGUiOiJyZWZyZXNoIiwiaWF0IjoxNzU4NjU3NTE3LCJleHAiOjE3NTkyNjIzMTd9.-E5S9UwplJBrEL25or-o2JloTBnw8uqkuGh2yp_fUOQ	2025-09-30 19:58:37.513	2025-09-23 19:58:37.514078	172.26.0.7	python-requests/2.31.0
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tags (id, note_id, tag, created_at) FROM stdin;
04c0571e-f9fb-4464-ad0d-5c4b74feb6be	62d6m	test	2025-09-23 20:02:42.485+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: zettl_auth
--

COPY public.users (id, username, email, password_hash, role, api_key, created_at, updated_at, last_login, is_active, metadata) FROM stdin;
2	testuser	test@example.com	$2b$10$PsZ18ABx4vXMQHf4mKhaWexOiUJ4lk1NxXarIskHEvkd/00lYVan6	user	\N	2025-09-23 18:46:50.735744	2025-09-23 18:46:50.735744	2025-09-23 19:33:48.079668	t	{}
1	greg	g.defoy@proton.me	$2b$10$4lyDoQkiyu1uFY6zlkOmAu10.CR05Zdanr5tQCD6MCc70g60vAWDW	user	\N	2025-09-22 19:41:10.008143	2025-09-22 19:41:10.008143	2025-09-23 19:58:37.516103	t	{}
\.


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zettl_auth
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 1, true);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zettl_auth
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 13, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zettl_auth
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: links links_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_pkey PRIMARY KEY (id);


--
-- Name: links links_source_id_target_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_source_id_target_id_key UNIQUE (source_id, target_id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_key UNIQUE (token);


--
-- Name: tags tags_note_id_tag_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_note_id_tag_key UNIQUE (note_id, tag);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: users users_api_key_key; Type: CONSTRAINT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_api_key_key UNIQUE (api_key);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_links_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_links_source ON public.links USING btree (source_id);


--
-- Name: idx_links_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_links_target ON public.links USING btree (target_id);


--
-- Name: idx_notes_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notes_created_at ON public.notes USING btree (created_at DESC);


--
-- Name: idx_tags_note; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tags_note ON public.tags USING btree (note_id);


--
-- Name: idx_tags_tag; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tags_tag ON public.tags USING btree (tag);


--
-- Name: notes update_notes_modified; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_notes_modified BEFORE UPDATE ON public.notes FOR EACH ROW EXECUTE FUNCTION public.update_modified_column();


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: links links_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.notes(id) ON DELETE CASCADE;


--
-- Name: links links_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.notes(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zettl_auth
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tags tags_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.notes(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO zettl_auth;
GRANT USAGE ON SCHEMA public TO "user";


--
-- Name: TABLE api_keys; Type: ACL; Schema: public; Owner: zettl_auth
--

GRANT ALL ON TABLE public.api_keys TO "user";


--
-- Name: SEQUENCE api_keys_id_seq; Type: ACL; Schema: public; Owner: zettl_auth
--

GRANT SELECT,USAGE ON SEQUENCE public.api_keys_id_seq TO "user";


--
-- Name: TABLE links; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.links TO zettl_auth;
GRANT ALL ON TABLE public.links TO "user";


--
-- Name: TABLE notes; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notes TO zettl_auth;
GRANT ALL ON TABLE public.notes TO "user";


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: public; Owner: zettl_auth
--

GRANT ALL ON TABLE public.refresh_tokens TO "user";


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: public; Owner: zettl_auth
--

GRANT SELECT,USAGE ON SEQUENCE public.refresh_tokens_id_seq TO "user";


--
-- Name: TABLE tags; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tags TO zettl_auth;
GRANT ALL ON TABLE public.tags TO "user";


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: zettl_auth
--

GRANT ALL ON TABLE public.users TO "user";


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: zettl_auth
--

GRANT SELECT,USAGE ON SEQUENCE public.users_id_seq TO "user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO zettl_auth;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO zettl_auth;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO zettl_auth;


--
-- PostgreSQL database dump complete
--

